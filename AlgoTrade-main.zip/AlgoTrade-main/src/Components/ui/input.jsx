import React from "react";
export function Input(props) {
  return <input {...props} />;
}