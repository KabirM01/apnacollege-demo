import React from "react";
export function Badge({ children }) {
  return <span className="badge">{children}</span>;
}