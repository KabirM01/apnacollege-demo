import React from "react";
export function Alert({ children }) {
  return <div className="alert">{children}</div>;
}

export function AlertDescription(){
  return <div className="alert-description"></div>;
}