import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Area,
  AreaChart
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Activity, Clock } from 'lucide-react';
import TimeFrameSelector from "./TimeFrameSelector.jsx";
import FundamentalsCard from "./FundamentalsCard.jsx";

export default function PriceChart({ data, title, type = 'candlestick', timeframe, onTimeframeChange }) {
  const [selectedTimeframe, setSelectedTimeframe] = React.useState(timeframe || '1mo');

  const handleTimeframeChange = (newTimeframe) => {
    setSelectedTimeframe(newTimeframe.value);
    if (onTimeframeChange) {
      onTimeframeChange(newTimeframe);
    }
  };

  const getFilteredData = () => {
    if (!data || data.length === 0) return [];
    
    const timeframeObj = selectedTimeframe;
    let filteredData = [...data];
    
    // Filter based on timeframe
    if (typeof timeframeObj === 'string') {
      switch (timeframeObj) {
        case '15s':
          // For demo, show last 4 hours worth of 15-second intervals
          return filteredData.slice(-240);
        case '1m':
          // Show last trading day (390 minutes)
          return filteredData.slice(-390);
        case '5m':
          // Show last 3 days
          return filteredData.slice(-78 * 3);
        case '15m':
          // Show last week
          return filteredData.slice(-26 * 5);
        case '1h':
          // Show last month (30 trading days)
          return filteredData.slice(-7 * 30);
        case '1d':
        case '1D':
          // Show last 100 days
          return filteredData.slice(-100);
        case '1w':
        case '1W':
          // Weekly data - every 7th day for last year
          return filteredData.filter((_, index) => index % 7 === 0).slice(-52);
        case '1M':
          // Monthly data - every 30th day for last 2 years
          return filteredData.filter((_, index) => index % 30 === 0).slice(-24);
        case '1mo':
          // Last 30 days
          return filteredData.slice(-30);
        case '3mo':
          // Last 90 days
          return filteredData.slice(-90);
        case '6mo':
          // Last 180 days
          return filteredData.slice(-180);
        case '1y':
          // Last 365 days
          return filteredData.slice(-365);
        case '2y':
          // Last 2 years, every other day
          return filteredData.filter((_, index) => index % 2 === 0).slice(-365);
        case '5y':
          // Last 5 years, every 5th day
          return filteredData.filter((_, index) => index % 5 === 0).slice(-365);
        case 'max':
          // All available data, sampled
          if (filteredData.length > 1000) {
            const step = Math.ceil(filteredData.length / 1000);
            return filteredData.filter((_, index) => index % step === 0);
          }
          return filteredData;
        default:
          return filteredData.slice(-100);
      }
    }
    
    return filteredData.slice(-100);
  };

  const chartData = getFilteredData();

  const getDateFormatter = () => {
    switch (selectedTimeframe) {
      case '15s':
      case '1m':
      case '5m':
      case '15m':
      case '1h':
        return (date) => {
          const d = new Date(date);
          return d.toLocaleTimeString('en-IN', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
          });
        };
      case '1d':
      case '1D':
      case '1mo':
      case '3mo':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
      case '6mo':
      case '1y':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
      case '1w':
      case '1W':
      case '2y':
      case '5y':
      case 'max':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          year: '2-digit' 
        });
      default:
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
    }
  };

  const renderCandlestickChart = () => (
    <ResponsiveContainer width="100%" height={450}>
      <ComposedChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis />
        <Tooltip 
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload;
              const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
              return (
                <div className="bg-white p-3 border rounded shadow-lg">
                  <p className="font-semibold">
                    {isIntraday 
                      ? new Date(label).toLocaleString('en-IN')
                      : new Date(label).toLocaleDateString('en-IN')
                    }
                  </p>
                  <p className="text-green-600">Open: ₹{data.open.toFixed(2)}</p>
                  <p className="text-red-600">High: ₹{data.high.toFixed(2)}</p>
                  <p className="text-blue-600">Low: ₹{data.low.toFixed(2)}</p>
                  <p className="text-purple-600">Close: ₹{data.close.toFixed(2)}</p>
                  <p className="text-gray-600">Volume: {data.volume.toLocaleString('en-IN')}</p>
                  {isIntraday && <p className="text-xs text-gray-500 mt-1">⚡ Live Data</p>}
                </div>
              );
            }
            return null;
          }}
        />
        <Line 
          type="monotone" 
          dataKey="close" 
          stroke="#3b82f6" 
          strokeWidth={2} 
          dot={false} 
          name="Close Price" 
        />
        {data[0]?.dema50 && (
          <Line 
            type="monotone" 
            dataKey="dema50" 
            stroke="#f59e0b" 
            strokeWidth={1} 
            dot={false} 
            name="50 DEMA" 
            strokeDasharray="5 5"
          />
        )}
      </ComposedChart>
    </ResponsiveContainer>
  );

  const renderVolumeChart = () => (
    <ResponsiveContainer width="100%" height={450}>
      <ComposedChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis yAxisId="price" />
        <YAxis yAxisId="volume" orientation="right" />
        <Tooltip 
          formatter={(value, name) => {
            if (name === 'Volume') {
              return [value.toLocaleString('en-IN'), name];
            }
            return [`₹${value.toFixed(2)}`, name];
          }}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line 
          yAxisId="price"
          type="monotone" 
          dataKey="close" 
          stroke="#3b82f6" 
          strokeWidth={2} 
          dot={false} 
          name="Close Price" 
        />
        <Bar 
          yAxisId="volume"
          dataKey="volume" 
          fill="#e5e7eb" 
          name="Volume"
          opacity={0.6}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );

  const getTimeframeInfo = () => {
    const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
    return {
      isIntraday,
      dataPoints: chartData.length,
      period: selectedTimeframe
    };
  };

  const timeframeInfo = getTimeframeInfo();

  return (
    <Card className="shadow-lg">
      <CardHeader className="space-y-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            {type === 'volume' ? (
              <Activity className="h-6 w-6 text-blue-600" />
            ) : (
              <BarChart3 className="h-6 w-6 text-green-600" />
            )}
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            {timeframeInfo.isIntraday && (
              <div className="flex items-center gap-1 text-red-600 text-sm">
                <Clock className="h-4 w-4" />
                Live
              </div>
            )}
            <span className="text-sm text-gray-500">
              {timeframeInfo.dataPoints} points
            </span>
          </div>
        </div>

        {/* Time Frame Selector */}
        <TimeFrameSelector 
          activeTimeframe={selectedTimeframe}
          onTimeframeChange={handleTimeframeChange}
        />
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          type === 'volume' ? renderVolumeChart() : renderCandlestickChart()
        ) : (
          <div className="h-96 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No data available for selected timeframe</p>
              <p className="text-sm mt-2">Try selecting a different period</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}