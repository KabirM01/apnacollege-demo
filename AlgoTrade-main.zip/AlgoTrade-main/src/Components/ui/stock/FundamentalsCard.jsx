import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, TrendingDown, Target, CheckCircle, AlertTriangle } from 'lucide-react';

export default function FundamentalsCard({ fundamentals, stockData, symbol }) {
  if (!fundamentals || !stockData || stockData.length === 0) {
    return (
      <Card className="shadow-lg">
        <CardContent className="p-8 text-center">
          <div className="animate-spin h-8 w-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading fundamental data...</p>
        </CardContent>
      </Card>
    );
  }

  const latestData = stockData[stockData.length - 1] || {};
  const latestPrice = latestData.close || 0;
  const week52High = fundamentals.week52High || Math.max(...stockData.map(d => d.high || 0));
  const week52Low = fundamentals.week52Low || Math.min(...stockData.map(d => d.low || 0));

  // Safe number formatting function
  const safeToFixed = (value, decimals = 2) => {
    if (value === null || value === undefined || isNaN(value)) {
      return '0.00';
    }
    return Number(value).toFixed(decimals);
  };

  // Safe number display
  const safeNumber = (value, fallback = 0) => {
    if (value === null || value === undefined || isNaN(value)) {
      return fallback;
    }
    return Number(value);
  };

  // Generate overall trading recommendation
  const generateTradeRecommendation = () => {
    const rsi = safeNumber(latestData.rsi, 50);
    const price = safeNumber(latestData.close, 0);
    const bbUpper = safeNumber(latestData.bbUpper, price * 1.05);
    const bbLower = safeNumber(latestData.bbLower, price * 0.95);
    const dema50 = safeNumber(latestData.dema50, price);
    
    let buySignals = 0;
    let sellSignals = 0;
    let signals = [];
    
    // RSI Analysis
    if (rsi <= 30 && price > 0) { // Only consider RSI if price is valid
      buySignals++;
      signals.push("RSI Oversold");
    } else if (rsi >= 70 && price > 0) {
      sellSignals++;
      signals.push("RSI Overbought");
    }
    
    // Bollinger Band Analysis
    if (price > 0) { // Only consider BB if price is valid
      if (price < bbLower) {
        buySignals++;
        signals.push("Below BB Lower");
      } else if (price > bbUpper) {
        sellSignals++;
        signals.push("Above BB Upper");
      }
    }
    
    // DEMA Trend Analysis
    if (price > 0) { // Only consider DEMA if price is valid
      if (price > dema50) {
        buySignals++;
        signals.push("Above 50 DEMA");
      } else if (price < dema50) {
        sellSignals++;
        signals.push("Below 50 DEMA");
      }
    }
    
    // Generate recommendation
    let recommendation = "HOLD";
    let confidence = "Medium";
    let action = "Hold current position";
    let entryPrice = price;
    let target = price;
    let stopLoss = price;
    let timeframe = "1-3 weeks";
    
    if (buySignals > sellSignals && price > 0) {
      recommendation = "BUY";
      confidence = buySignals >= 2 ? "High" : "Medium";
      action = "Consider buying";
      entryPrice = price * 0.98; // Buy 2% below current
      target = price * 1.08; // 8% upside target
      stopLoss = price * 0.94; // 6% stop loss
      timeframe = buySignals >= 2 ? "2-4 weeks" : "3-6 weeks";
    } else if (sellSignals > buySignals && price > 0) {
      recommendation = "SELL";
      confidence = sellSignals >= 2 ? "High" : "Medium";
      action = "Consider selling";
      entryPrice = price * 1.02; // Sell 2% above current
      target = price * 0.92; // 8% downside target
      stopLoss = price * 1.06; // 6% stop loss
      timeframe = sellSignals >= 2 ? "2-4 weeks" : "3-6 weeks";
    }
    
    return {
      recommendation,
      confidence,
      action,
      entryPrice,
      target,
      stopLoss,
      timeframe,
      signals: signals.length > 0 ? signals.join(", ") : "No clear signals",
      totalSignals: buySignals + sellSignals
    };
  };

  const tradeRec = generateTradeRecommendation();


  const getPBRatioStatus = (ratio) => {
    if (!ratio || ratio <= 1) return { status: 'Excellent', color: 'bg-green-100 text-green-800', icon: CheckCircle };
    if (ratio <= 2) return { status: 'Good', color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle };
    return { status: 'High', color: 'bg-red-100 text-red-800', icon: AlertTriangle };
  };

  const pbStatus = getPBRatioStatus(fundamentals.pbRatio);

  return (
    <div className="space-y-6">
      
      {/* Trading Prediction Card - NEW */}
      <Card className="shadow-xl border-2 border-blue-200">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Target className="h-8 w-8 text-blue-600" />
            AI Trading Prediction - {symbol}
          </CardTitle>
          <p className="text-gray-600">Technical analysis based recommendation</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Recommendation */}
            <div className={`p-6 rounded-lg text-center ${
              tradeRec.recommendation === 'BUY' ? 'bg-green-50 border-2 border-green-300' :
              tradeRec.recommendation === 'SELL' ? 'bg-red-50 border-2 border-red-300' :
              'bg-yellow-50 border-2 border-yellow-300'
            }`}>
              <div className={`text-4xl font-bold mb-2 ${
                tradeRec.recommendation === 'BUY' ? 'text-green-600' :
                tradeRec.recommendation === 'SELL' ? 'text-red-600' :
                'text-yellow-600'
              }`}>
                {tradeRec.recommendation}
              </div>
              <Badge className={`mb-3 ${
                tradeRec.confidence === 'High' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
              }`}>
                {tradeRec.confidence} Confidence
              </Badge>
              <div className="text-sm text-gray-700">{tradeRec.action}</div>
              <div className="text-xs text-gray-600 mt-2">
                Based on: {tradeRec.signals}
              </div>
            </div>

            {/* Trading Levels */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg text-center">
                  <div className="text-lg font-bold text-blue-600">
                    ₹{safeToFixed(tradeRec.entryPrice, 2)}
                  </div>
                  <div className="text-sm text-gray-600">Entry Price</div>
                </div>
                
                <div className="p-4 bg-green-50 rounded-lg text-center">
                  <div className="text-lg font-bold text-green-600">
                    ₹{safeToFixed(tradeRec.target, 2)}
                  </div>
                  <div className="text-sm text-gray-600">Target</div>
                </div>
                
                <div className="p-4 bg-red-50 rounded-lg text-center">
                  <div className="text-lg font-bold text-red-600">
                    ₹{safeToFixed(tradeRec.stopLoss, 2)}
                  </div>
                  <div className="text-sm text-gray-600">Stop Loss</div>
                </div>
                
                <div className="p-4 bg-purple-50 rounded-lg text-center">
                  <div className="text-lg font-bold text-purple-600">
                    {tradeRec.timeframe}
                  </div>
                  <div className="text-sm text-gray-600">Time Frame</div>
                </div>
              </div>
              
              {/* Risk-Reward */}
              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="text-sm font-medium text-gray-700 mb-2">Risk-Reward Analysis:</div>
                <div className="text-xs text-gray-600">
                  Risk: {safeToFixed(Math.abs((safeNumber(tradeRec.entryPrice) - safeNumber(tradeRec.stopLoss)) / safeNumber(tradeRec.entryPrice, 1)) * 100, 1)}% | 
                  Reward: {safeToFixed(Math.abs((safeNumber(tradeRec.target) - safeNumber(tradeRec.entryPrice)) / safeNumber(tradeRec.entryPrice, 1)) * 100, 1)}%
                </div>
                <div className="text-xs text-gray-600 mt-1">
                  R:R Ratio = 1:
                  {safeToFixed(
                    safeNumber(tradeRec.entryPrice) - safeNumber(tradeRec.stopLoss) !== 0
                      ? Math.abs(safeNumber(tradeRec.target) - safeNumber(tradeRec.entryPrice)) / Math.abs(safeNumber(tradeRec.entryPrice) - safeNumber(tradeRec.stopLoss))
                      : 0,
                    1
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Overview */}
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <DollarSign className="h-8 w-8 text-green-600" />
            Fundamental Analysis - {symbol}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Market Cap */}
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                ₹{safeNumber(fundamentals.marketCapCrores, 50000).toLocaleString('en-IN')}Cr
              </div>
              <div className="text-sm text-gray-600 mb-2">Market Cap</div>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                {fundamentals.marketCapCategory || 'Large Cap'}
              </Badge>
            </div>

            {/* P/E Ratio */}
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {safeToFixed(fundamentals.peRatio || 22.5, 1)}x
              </div>
              <div className="text-sm text-gray-600 mb-2">P/E Ratio</div>
              <div className="text-xs text-purple-600">Price to Earnings</div>
            </div>

            {/* P/B Ratio */}
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="flex items-center justify-center gap-2 mb-2">
                <pbStatus.icon className="h-5 w-5" />
                <div className="text-2xl font-bold text-green-600">
                  {safeToFixed(fundamentals.pbRatio || 1.2, 2)}x
                </div>
              </div>
              <div className="text-sm text-gray-600 mb-2">P/B Ratio</div>
              <Badge className={pbStatus.color}>
                {pbStatus.status}
                {safeNumber(fundamentals.pbRatio) <= 1 && " ✓ ≤1"}
              </Badge>
            </div>

            {/* EPS */}
            <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                ₹{safeToFixed(fundamentals.eps || 45.2, 2)}
              </div>
              <div className="text-sm text-gray-600 mb-2">EPS</div>
              <div className="text-xs text-orange-600">Earnings Per Share</div>
            </div>

          </div>
        </CardContent>
      </Card>

      {/* Price Performance */}
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-6 w-6 text-indigo-600" />
            Price Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Current Price */}
            <div className="text-center p-4 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg">
              <div className="text-3xl font-bold text-indigo-600">
                ₹{safeToFixed(latestPrice, 2)}
              </div>
              <div className="text-sm text-gray-600">Current Price</div>
              <div className="text-xs text-indigo-600 mt-1">Live Quote</div>
            </div>

            {/* 52-Week High */}
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="flex items-center justify-center gap-2 mb-1">
                <TrendingUp className="h-5 w-5 text-green-600" />
                <div className="text-2xl font-bold text-green-600">
                  ₹{safeToFixed(week52High, 2)}
                </div>
              </div>
              <div className="text-sm text-gray-600 mb-2">52-Week High</div>
              <div className="text-xs text-green-600">
                {week52High > 0 ? safeToFixed(((latestPrice - week52High) / week52High) * 100, 1) : '0.0'}% from high
              </div>
            </div>

            {/* 52-Week Low */}
            <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg">
              <div className="flex items-center justify-center gap-2 mb-1">
                <TrendingDown className="h-5 w-5 text-red-600" />
                <div className="text-2xl font-bold text-red-600">
                  ₹{safeToFixed(week52Low, 2)}
                </div>
              </div>
              <div className="text-sm text-gray-600 mb-2">52-Week Low</div>
              <div className="text-xs text-red-600">
                +{week52Low > 0 ? safeToFixed(((latestPrice - week52Low) / week52Low) * 100, 1) : '0.0'}% from low
              </div>
            </div>

          </div>
        </CardContent>
      </Card>

      {/* Additional Metrics - UPDATED WITH RSI */}
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle>Technical & Additional Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* RSI - FIXED AND PROMINENT */}
            <div className={`p-4 border-2 rounded-lg ${
              safeNumber(latestData.rsi, 50) <= 30 ? 'border-green-300 bg-green-50' :
              safeNumber(latestData.rsi, 50) >= 70 ? 'border-red-300 bg-red-50' :
              'border-blue-300 bg-blue-50'
            }`}>
              <div className={`text-xl font-bold ${
                safeNumber(latestData.rsi, 50) <= 30 ? 'text-green-600' :
                safeNumber(latestData.rsi, 50) >= 70 ? 'text-red-600' :
                'text-blue-600'
              }`}>
                {latestData.rsi ? safeToFixed(latestData.rsi, 1) : 'N/A'}
              </div>
              <div className="text-sm text-gray-600 mb-1">Current RSI</div>
              <div className="text-xs font-medium">
                {safeNumber(latestData.rsi, 50) <= 30 ? '🟢 Oversold' :
                 safeNumber(latestData.rsi, 50) >= 70 ? '🔴 Overbought' :
                 '🟡 Neutral'}
              </div>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="text-lg font-semibold text-gray-800">
                {safeToFixed(fundamentals.dividendYield || 1.8, 2)}%
              </div>
              <div className="text-sm text-gray-600">Dividend Yield</div>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="text-lg font-semibold text-gray-800">
                ₹{safeToFixed(fundamentals.bookValue || 285.5, 2)}
              </div>
              <div className="text-sm text-gray-600">Book Value</div>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="text-lg font-semibold text-gray-800">
                {fundamentals.sector || 'Technology'}
              </div>
              <div className="text-sm text-gray-600">Sector</div>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="text-lg font-semibold text-gray-800">
                {latestData.volume ? safeToFixed(latestData.volume / 1000000, 1) : '0.0'}M
              </div>
              <div className="text-sm text-gray-600">Today's Volume</div>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="text-lg font-semibold text-gray-800">
                ₹{week52High > 0 && week52Low > 0 ? safeToFixed((week52High + week52Low) / 2, 2) : '0.00'}
              </div>
              <div className="text-sm text-gray-600">52W Avg</div>
            </div>

          </div>
        </CardContent>
      </Card>
    </div>
  );
}
