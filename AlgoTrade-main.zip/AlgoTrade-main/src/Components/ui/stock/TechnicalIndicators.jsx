import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Area,
  AreaChart
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Target,
  Layers,
  Clock
} from 'lucide-react';
import TimeFrameSelector from "./TimeFrameSelector.jsx";

export default function TechnicalIndicators({ data, type, title, timeframe, onTimeframeChange }) {
  const [selectedTimeframe, setSelectedTimeframe] = React.useState(timeframe || '1mo');

  const handleTimeframeChange = (newTimeframe) => {
    setSelectedTimeframe(newTimeframe.value);
    if (onTimeframeChange) {
      onTimeframeChange(newTimeframe);
    }
  };

  const getFilteredData = () => {
    if (!data || data.length === 0) return [];
    
    let filteredData = [...data];
    
    // Filter based on timeframe - same logic as PriceChart
    switch (selectedTimeframe) {
      case '15s':
        return filteredData.slice(-240);
      case '1m':
        return filteredData.slice(-390);
      case '5m':
        return filteredData.slice(-78 * 3);
      case '15m':
        return filteredData.slice(-26 * 5);
      case '1h':
        return filteredData.slice(-7 * 30);
      case '1d':
      case '1D':
        return filteredData.slice(-100);
      case '1w':
      case '1W':
        return filteredData.filter((_, index) => index % 7 === 0).slice(-52);
      case '1M':
        return filteredData.filter((_, index) => index % 30 === 0).slice(-24);
      case '1mo':
        return filteredData.slice(-30);
      case '3mo':
        return filteredData.slice(-90);
      case '6mo':
        return filteredData.slice(-180);
      case '1y':
        return filteredData.slice(-365);
      case '2y':
        return filteredData.filter((_, index) => index % 2 === 0).slice(-365);
      case '5y':
        return filteredData.filter((_, index) => index % 5 === 0).slice(-365);
      case 'max':
        if (filteredData.length > 1000) {
          const step = Math.ceil(filteredData.length / 1000);
          return filteredData.filter((_, index) => index % step === 0);
        }
        return filteredData;
      default:
        return filteredData.slice(-100);
    }
  };

  const chartData = getFilteredData();
  
  const getIcon = () => {
    switch (type) {
      case 'rsi': return <Activity className="h-6 w-6 text-purple-600" />;
      case 'stochastic': return <TrendingUp className="h-6 w-6 text-orange-600" />;
      case 'macd': return <TrendingDown className="h-6 w-6 text-indigo-600" />;
      case 'bollinger': return <Target className="h-6 w-6 text-pink-600" />;
      case 'dema': return <Layers className="h-6 w-6 text-emerald-600" />;
      default: return <Activity className="h-6 w-6 text-gray-600" />;
    }
  };

  const getDateFormatter = () => {
    switch (selectedTimeframe) {
      case '15s':
      case '1m':
      case '5m':
      case '15m':
      case '1h':
        return (date) => {
          const d = new Date(date);
          return d.toLocaleTimeString('en-IN', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false 
          });
        };
      case '1d':
      case '1D':
      case '1mo':
      case '3mo':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
      case '6mo':
      case '1y':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
      case '1w':
      case '1W':
      case '2y':
      case '5y':
      case 'max':
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          year: '2-digit' 
        });
      default:
        return (date) => new Date(date).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric' 
        });
    }
  };

  const renderRSI = () => (
    <ResponsiveContainer width="100%" height={450}>
      <LineChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis domain={[0, 100]} />
        <Tooltip 
          formatter={(value, name) => [`${value.toFixed(1)}`, name]}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line type="monotone" dataKey="rsi" stroke="#8b5cf6" strokeWidth={2} name="RSI" dot={false} />
        <Line type="monotone" dataKey={() => 70} stroke="#ef4444" strokeDasharray="5 5" name="Overbought (70)" dot={false} />
        <Line type="monotone" dataKey={() => 30} stroke="#10b981" strokeDasharray="5 5" name="Oversold (30)" dot={false} />
        <Line type="monotone" dataKey={() => 50} stroke="#6b7280" strokeDasharray="2 2" name="Neutral (50)" dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );

  const renderStochastic = () => (
    <ResponsiveContainer width="100%" height={450}>
      <LineChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis domain={[0, 100]} />
        <Tooltip 
          formatter={(value, name) => [`${value.toFixed(1)}`, name]}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line type="monotone" dataKey="stochK" stroke="#f59e0b" strokeWidth={2} name="%K" dot={false} />
        <Line type="monotone" dataKey="stochD" stroke="#ef4444" strokeWidth={2} name="%D" dot={false} />
        <Line type="monotone" dataKey={() => 80} stroke="#dc2626" strokeDasharray="5 5" name="Overbought (80)" dot={false} />
        <Line type="monotone" dataKey={() => 20} stroke="#059669" strokeDasharray="5 5" name="Oversold (20)" dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );

  const renderMACD = () => (
    <ResponsiveContainer width="100%" height={450}>
      <ComposedChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis />
        <Tooltip 
          formatter={(value, name) => [`${value.toFixed(3)}`, name]}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line type="monotone" dataKey="macd" stroke="#6366f1" strokeWidth={2} name="MACD Line" dot={false} />
        <Line type="monotone" dataKey="macdSignal" stroke="#f59e0b" strokeWidth={2} name="Signal Line" dot={false} />
        <Bar dataKey="macdHistogram" fill="#10b981" name="Histogram" />
      </ComposedChart>
    </ResponsiveContainer>
  );

  const renderBollingerBands = () => (
    <ResponsiveContainer width="100%" height={450}>
      <ComposedChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis />
        <Tooltip 
          formatter={(value, name) => [`₹${value.toFixed(2)}`, name]}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line type="monotone" dataKey="close" stroke="#3b82f6" strokeWidth={2} name="Close Price" dot={false} />
        <Line type="monotone" dataKey="bbUpper" stroke="#ef4444" strokeWidth={1} name="Upper Band" dot={false} strokeDasharray="3 3" />
        <Line type="monotone" dataKey="bbMiddle" stroke="#6b7280" strokeWidth={1} name="Middle Band (SMA 20)" dot={false} />
        <Line type="monotone" dataKey="bbLower" stroke="#10b981" strokeWidth={1} name="Lower Band" dot={false} strokeDasharray="3 3" />
      </ComposedChart>
    </ResponsiveContainer>
  );

  const renderDEMA = () => (
    <ResponsiveContainer width="100%" height={450}>
      <LineChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 10 }}
          tickFormatter={getDateFormatter()}
        />
        <YAxis />
        <Tooltip 
          formatter={(value, name) => [`₹${value.toFixed(2)}`, name]}
          labelFormatter={(date) => {
            const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
            return isIntraday 
              ? new Date(date).toLocaleString('en-IN')
              : new Date(date).toLocaleDateString('en-IN');
          }}
        />
        <Legend />
        <Line type="monotone" dataKey="close" stroke="#3b82f6" strokeWidth={2} name="Close Price" dot={false} />
        <Line type="monotone" dataKey="dema50" stroke="#10b981" strokeWidth={2} name="50 DEMA" dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );

  const renderChart = () => {
    switch (type) {
      case 'rsi': return renderRSI();
      case 'stochastic': return renderStochastic();
      case 'macd': return renderMACD();
      case 'bollinger': return renderBollingerBands();
      case 'dema': return renderDEMA();
      default: return renderRSI();
    }
  };

  const getTimeframeInfo = () => {
    const isIntraday = ['15s', '1m', '5m', '15m', '1h'].includes(selectedTimeframe);
    return {
      isIntraday,
      dataPoints: chartData.length,
      period: selectedTimeframe
    };
  };

  const timeframeInfo = getTimeframeInfo();

  return (
    <Card className="shadow-lg">
      <CardHeader className="space-y-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            {getIcon()}
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            {timeframeInfo.isIntraday && (
              <div className="flex items-center gap-1 text-red-600 text-sm">
                <Clock className="h-4 w-4" />
                Live
              </div>
            )}
            <span className="text-sm text-gray-500">
              {timeframeInfo.dataPoints} points
            </span>
          </div>
        </div>

        {/* Time Frame Selector */}
        <TimeFrameSelector 
          activeTimeframe={selectedTimeframe}
          onTimeframeChange={handleTimeframeChange}
        />
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          renderChart()
        ) : (
          <div className="h-96 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No data available for selected timeframe</p>
              <p className="text-sm mt-2">Try selecting a different period</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}