import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function NewsSection({ news, symbol }) {
  const getSentimentIcon = (sentiment) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'negative': return <TrendingDown className="h-4 w-4 text-red-600" />;
      default: return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getSentimentColor = (sentiment) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return 'bg-green-100 text-green-800';
      case 'negative': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!news || news.length === 0) {
    return (
      <Card className="shadow-lg">
        <CardContent className="p-8 text-center">
          <div className="animate-spin h-8 w-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading latest news for {symbol}...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-2xl">
          <ExternalLink className="h-8 w-8 text-blue-600" />
          Latest News - {symbol}
        </CardTitle>
        <p className="text-gray-600">Stay updated with the latest developments</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {news.map((article, index) => (
            <div 
              key={index}
              className="p-6 border border-gray-200 rounded-lg hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  {getSentimentIcon(article.sentiment)}
                  <Badge className={getSentimentColor(article.sentiment)}>
                    {article.sentiment || 'Neutral'}
                  </Badge>
                </div>
                <div className="text-sm text-gray-500">
                  {article.time || `${index + 1} hours ago`}
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-gray-900 mb-2 hover:text-blue-600 cursor-pointer">
                {article.title || `${symbol} Market Update ${index + 1}`}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {article.description || `Latest developments regarding ${symbol} stock performance and market outlook.`}
              </p>
              
              <div className="mt-4 pt-3 border-t border-gray-100">
                <button className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-1">
                  Read full article
                  <ExternalLink className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
          
          {news.length === 0 && (
            <div className="text-center py-8">
              <ExternalLink className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No recent news available for {symbol}</p>
              <p className="text-sm text-gray-500 mt-2">Check back later for updates</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}