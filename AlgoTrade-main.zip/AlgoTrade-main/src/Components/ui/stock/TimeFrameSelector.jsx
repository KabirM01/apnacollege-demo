import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Calendar } from 'lucide-react';
import FundamentalsCard from "./FundamentalsCard.jsx";

export default function TimeFrameSelector({ activeTimeframe, onTimeframeChange, className = "" }) {
  const timeframes = [
    // Intraday options
    { 
      value: '15s', 
      label: '15s', 
      type: 'intraday',
      description: '15 Seconds',
      dataPoints: 240 // 1 hour worth
    },
    { 
      value: '1m', 
      label: '1m', 
      type: 'intraday',
      description: '1 Minute',
      dataPoints: 390 // 6.5 hours (trading day)
    },
    { 
      value: '5m', 
      label: '5m', 
      type: 'intraday',
      description: '5 Minutes',
      dataPoints: 78 // Trading day
    },
    { 
      value: '15m', 
      label: '15m', 
      type: 'intraday',
      description: '15 Minutes',
      dataPoints: 26 // Trading day
    },
    { 
      value: '1h', 
      label: '1h', 
      type: 'intraday',
      description: '1 Hour',
      dataPoints: 7 // Trading day
    },
    
    // Daily and longer options
    { 
      value: '1d', 
      label: '1D', 
      type: 'daily',
      description: '1 Day',
      dataPoints: 30 // 1 month
    },
    { 
      value: '1w', 
      label: '1W', 
      type: 'weekly',
      description: '1 Week',
      dataPoints: 52 // 1 year
    },
    { 
      value: '1M', 
      label: '1M', 
      type: 'monthly',
      description: '1 Month',
      dataPoints: 24 // 2 years
    },
    
    // Period selectors
    { 
      value: '1mo', 
      label: '1M', 
      type: 'period',
      description: '1 Month',
      days: 30
    },
    { 
      value: '3mo', 
      label: '3M', 
      type: 'period',
      description: '3 Months',
      days: 90
    },
    { 
      value: '6mo', 
      label: '6M', 
      type: 'period',
      description: '6 Months',
      days: 180
    },
    { 
      value: '1y', 
      label: '1Y', 
      type: 'period',
      description: '1 Year',
      days: 365
    },
    { 
      value: '2y', 
      label: '2Y', 
      type: 'period',
      description: '2 Years',
      days: 730
    },
    { 
      value: '5y', 
      label: '5Y', 
      type: 'period',
      description: '5 Years',
      days: 1825
    },
    { 
      value: 'max', 
      label: 'MAX', 
      type: 'period',
      description: 'All Time',
      days: null
    }
  ];

  const getTypeColor = (type) => {
    switch (type) {
      case 'intraday': return 'text-red-600 bg-red-50';
      case 'daily': return 'text-blue-600 bg-blue-50';
      case 'weekly': return 'text-green-600 bg-green-50';
      case 'monthly': return 'text-purple-600 bg-purple-50';
      case 'period': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const groupedTimeframes = timeframes.reduce((acc, tf) => {
    if (!acc[tf.type]) acc[tf.type] = [];
    acc[tf.type].push(tf);
    return acc;
  }, {});

  return (
    <div className={`space-y-4 ${className}`}>
      
      {/* Quick Period Selectors */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Quick Periods</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {groupedTimeframes.period?.map((timeframe) => (
            <Button
              key={timeframe.value}
              variant={activeTimeframe === timeframe.value ? "default" : "outline"}
              size="sm"
              onClick={() => onTimeframeChange(timeframe)}
              className={`
                ${activeTimeframe === timeframe.value 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : 'hover:bg-blue-50'
                }
              `}
            >
              {timeframe.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Intraday Options */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-red-500" />
          <span className="text-sm font-medium text-gray-700">Intraday</span>
          <Badge variant="secondary" className="text-xs bg-red-100 text-red-700">
            Real-time
          </Badge>
        </div>
        <div className="flex flex-wrap gap-2">
          {groupedTimeframes.intraday?.map((timeframe) => (
            <Button
              key={timeframe.value}
              variant={activeTimeframe === timeframe.value ? "default" : "outline"}
              size="sm"
              onClick={() => onTimeframeChange(timeframe)}
              className={`
                ${activeTimeframe === timeframe.value 
                  ? 'bg-red-600 hover:bg-red-700 text-white' 
                  : 'hover:bg-red-50 border-red-200'
                }
              `}
            >
              {timeframe.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Daily/Weekly/Monthly Options */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-green-500" />
          <span className="text-sm font-medium text-gray-700">Chart Intervals</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {[...groupedTimeframes.daily || [], ...groupedTimeframes.weekly || [], ...groupedTimeframes.monthly || []].map((timeframe) => (
            <Button
              key={timeframe.value}
              variant={activeTimeframe === timeframe.value ? "default" : "outline"}
              size="sm"
              onClick={() => onTimeframeChange(timeframe)}
              className={`
                ${activeTimeframe === timeframe.value 
                  ? 'bg-green-600 hover:bg-green-700 text-white' 
                  : 'hover:bg-green-50 border-green-200'
                }
              `}
            >
              {timeframe.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Current Selection Info */}
      {activeTimeframe && (
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium text-blue-900">
                Selected: {timeframes.find(tf => tf.value === activeTimeframe)?.description}
              </span>
              <div className="text-xs text-blue-700 mt-1">
                {timeframes.find(tf => tf.value === activeTimeframe)?.type === 'intraday' && 
                  "⚡ Live market data with real-time updates"}
                {timeframes.find(tf => tf.value === activeTimeframe)?.type === 'period' && 
                  `📊 Historical data for ${timeframes.find(tf => tf.value === activeTimeframe)?.description.toLowerCase()}`}
                {['daily', 'weekly', 'monthly'].includes(timeframes.find(tf => tf.value === activeTimeframe)?.type) && 
                  "📈 Candlestick chart with selected interval"}
              </div>
            </div>
            <Badge className={getTypeColor(timeframes.find(tf => tf.value === activeTimeframe)?.type)}>
              {timeframes.find(tf => tf.value === activeTimeframe)?.type}
            </Badge>
          </div>
        </div>
      )}
    </div>
  );
}