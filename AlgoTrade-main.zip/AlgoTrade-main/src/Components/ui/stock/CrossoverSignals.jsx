import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, TrendingUp, TrendingDown, AlertTriangle, CheckCircle } from 'lucide-react';

export default function CrossoverSignals({ signals }) {
  const getSignalIcon = (signal) => {
    switch (signal?.toUpperCase()) {
      case 'BUY': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'SELL': return <TrendingDown className="h-4 w-4 text-red-600" />;
      case 'HOLD': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default: return <CheckCircle className="h-4 w-4 text-gray-600" />;
    }
  };

  const getSignalColor = (signal) => {
    switch (signal?.toUpperCase()) {
      case 'BUY': return 'bg-green-100 text-green-800 border-green-300';
      case 'SELL': return 'bg-red-100 text-red-800 border-red-300';
      case 'HOLD': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStrengthColor = (strength) => {
    switch (strength?.toLowerCase()) {
      case 'strong': return 'bg-purple-100 text-purple-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'weak': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="shadow-xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-2xl">
          <Target className="h-8 w-8 text-indigo-600" />
          Crossover Signals & Trading Alerts
        </CardTitle>
        <p className="text-gray-600">Technical analysis signals based on crossover patterns</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {signals && signals.length > 0 ? (
            signals.map((signal, index) => (
              <div 
                key={index}
                className="p-6 border-2 border-gray-200 rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    {getSignalIcon(signal.signal)}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {signal.type || 'Technical Signal'}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {new Date(signal.date).toLocaleDateString('en-IN', {
                          year: 'numeric',
                          month: 'long', 
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col gap-2 items-end">
                    <Badge className={`border ${getSignalColor(signal.signal)}`}>
                      {signal.signal || 'NEUTRAL'}
                    </Badge>
                    {signal.strength && (
                      <Badge variant="secondary" className={getStrengthColor(signal.strength)}>
                        {signal.strength} Signal
                      </Badge>
                    )}
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed">
                  {signal.description || 'Technical crossover detected based on indicator analysis.'}
                </p>
                
                <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between items-center">
                  <div className="text-sm text-gray-500">
                    Signal Strength: <span className="font-medium">{signal.strength || 'Medium'}</span>
                  </div>
                  <div className="text-xs text-gray-400">
                    Generated: {signal.date}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <Target className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Recent Crossover Signals</h3>
              <p className="text-gray-600 mb-4">
                No significant crossover patterns detected in recent trading sessions.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-md mx-auto">
                <h4 className="font-medium text-blue-900 mb-2">What are Crossover Signals?</h4>
                <p className="text-sm text-blue-700">
                  Crossover signals occur when technical indicators cross above or below key levels or other indicators, 
                  potentially indicating trend changes or trading opportunities.
                </p>
              </div>
            </div>
          )}
          
          {/* Signal Legend */}
          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-3">Signal Types Explained:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span><strong>MACD Crossover:</strong> MACD line crosses signal line</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span><strong>Stochastic:</strong> %K and %D line crossovers</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span><strong>Price vs DEMA:</strong> Price crossing DEMA levels</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span><strong>Bollinger:</strong> Price touching band levels</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span><strong>RSI Extreme:</strong> Overbought/Oversold levels</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}