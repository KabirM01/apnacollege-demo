import StockAnalysis from '@/Pages/StockAnalysis';

function App() {
  return (
    <>
      <StockAnalysis />
    </>
  );
}

export default App;