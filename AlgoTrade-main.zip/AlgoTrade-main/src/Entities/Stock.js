// Stock entity class for managing stock data
export class Stock {
  constructor(data = {}) {
    this.symbol = data.symbol || '';
    this.company_name = data.company_name || '';
    this.sector = data.sector || '';
    this.market_cap_category = data.market_cap_category || '';
    this.last_updated = data.last_updated || new Date().toISOString();
  }

  // Create/save stock data (mock implementation)
  static async create(data) {
    try {
      const stock = new Stock(data);
      
      // Mock storage - in a real app this would save to a database
      console.log('Stock data saved:', stock);
      
      // Store in localStorage for persistence
      const existingStocks = JSON.parse(localStorage.getItem('stocks') || '[]');
      const stockIndex = existingStocks.findIndex(s => s.symbol === data.symbol);
      
      if (stockIndex >= 0) {
        existingStocks[stockIndex] = { ...existingStocks[stockIndex], ...data };
      } else {
        existingStocks.push(data);
      }
      
      localStorage.setItem('stocks', JSON.stringify(existingStocks));
      
      return stock;
    } catch (error) {
      console.error('Error creating stock:', error);
      throw error;
    }
  }

  // Find stock by symbol
  static async findBySymbol(symbol) {
    try {
      const existingStocks = JSON.parse(localStorage.getItem('stocks') || '[]');
      return existingStocks.find(stock => stock.symbol === symbol) || null;
    } catch (error) {
      console.error('Error finding stock:', error);
      return null;
    }
  }

  // Get all stocks
  static async findAll() {
    try {
      return JSON.parse(localStorage.getItem('stocks') || '[]');
    } catch (error) {
      console.error('Error getting stocks:', error);
      return [];
    }
  }
}

export default Stock;