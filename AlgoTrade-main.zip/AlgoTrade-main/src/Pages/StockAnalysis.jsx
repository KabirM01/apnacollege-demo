import React, { useState, useEffect } from 'react';
import { Stock } from '@/Entities/Stock.js';
import { InvokeLLM } from '@/integrations/core';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Activity, 
  TrendingUp, 
  TrendingDown,     
  BarChart3, 
  DollarSign,
  AlertCircle,
  CheckCircle,
  ExternalLink,
  Target,
  Layers
} from 'lucide-react';

import PriceChart from "../Components/ui/stock/PriceChart.jsx";
import TechnicalIndicators from "../Components/ui/stock/TechnicalIndicators.jsx";
import FundamentalsCard from "../Components/ui/stock/FundamentalsCard.jsx";
import NewsSection from "../Components/ui/stock/NewsSection.jsx";
import CrossoverSignals from "../Components/ui/stock/CrossoverSignals.jsx";

export default function StockAnalysis() {
  const [stockSymbol, setStockSymbol] = useState('');
  const [stockData, setStockData] = useState(null);
  const [fundamentals, setFundamentals] = useState(null);
  const [news, setNews] = useState([]);
  const [signals, setSignals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Technical analysis calculation functions
  const calculateTechnicalIndicators = (priceData) => {
    // RSI Calculation
    const calculateRSI = (data, period = 14) => {
      const gains = [];
      const losses = [];
      
      for (let i = 1; i < data.length; i++) {
        const change = data[i].close - data[i - 1].close;
        gains.push(change > 0 ? change : 0);
        losses.push(change < 0 ? Math.abs(change) : 0);
      }
      
      const rsiValues = [];
      for (let i = 0; i < data.length; i++) {
        if (i < period) {
          rsiValues.push(50);
        } else {
          const avgGain = gains.slice(i - period, i).reduce((sum, val) => sum + val, 0) / period;
          const avgLoss = losses.slice(i - period, i).reduce((sum, val) => sum + val, 0) / period;
          
          const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
          const rsi = 100 - (100 / (1 + rs));
          rsiValues.push(Math.round(rsi * 100) / 100);
        }
      }
      return rsiValues;
    };

    // MACD Calculation
    const calculateEMA = (data, period) => {
      const multiplier = 2 / (period + 1);
      const ema = [data[0].close];
      
      for (let i = 1; i < data.length; i++) {
        ema.push((data[i].close - ema[i - 1]) * multiplier + ema[i - 1]);
      }
      return ema;
    };

    const ema12 = calculateEMA(priceData, 12);
    const ema26 = calculateEMA(priceData, 26);
    const macdLine = ema12.map((val, i) => val - ema26[i]);
    
    // Signal line (9-period EMA of MACD)
    const signalMultiplier = 2 / 10;
    const signalLine = [macdLine[0]];
    for (let i = 1; i < macdLine.length; i++) {
      signalLine.push((macdLine[i] - signalLine[i - 1]) * signalMultiplier + signalLine[i - 1]);
    }
    
    const histogram = macdLine.map((val, i) => val - signalLine[i]);

    // Stochastic Calculation
    const calculateStochastic = (data, kPeriod = 14) => {
      const kValues = [];
      
      for (let i = 0; i < data.length; i++) {
        if (i < kPeriod - 1) {
          kValues.push(50);
        } else {
          const periodData = data.slice(i - kPeriod + 1, i + 1);
          const high = Math.max(...periodData.map(d => d.high));
          const low = Math.min(...periodData.map(d => d.low));
          const k = ((data[i].close - low) / (high - low)) * 100;
          kValues.push(Math.round(k * 100) / 100);
        }
      }
      
      // %D is 3-period SMA of %K
      const dValues = [];
      for (let i = 0; i < kValues.length; i++) {
        if (i < 2) {
          dValues.push(kValues[i]);
        } else {
          const sum = kValues.slice(i - 2, i + 1).reduce((acc, val) => acc + val, 0);
          dValues.push(Math.round((sum / 3) * 100) / 100);
        }
      }
      
      return { k: kValues, d: dValues };
    };

    // Bollinger Bands
    const calculateBollingerBands = (data, period = 20, stdDev = 2) => {
      const sma = [];
      const bands = { upper: [], middle: [], lower: [] };
      
      for (let i = 0; i < data.length; i++) {
        if (i < period - 1) {
          sma.push(data[i].close);
          bands.upper.push(null);
          bands.middle.push(null);
          bands.lower.push(null);
        } else {
          const periodData = data.slice(i - period + 1, i + 1);
          const mean = periodData.reduce((sum, d) => sum + d.close, 0) / period;
          sma.push(mean);
          
          const variance = periodData.reduce((sum, d) => sum + Math.pow(d.close - mean, 2), 0) / period;
          const standardDeviation = Math.sqrt(variance);
          
          bands.upper.push(mean + (standardDeviation * stdDev));
          bands.middle.push(mean);
          bands.lower.push(mean - (standardDeviation * stdDev));
        }
      }
      
      return bands;
    };

    // DEMA Calculation
    const calculateDEMA = (data, period = 50) => {
      const ema1 = calculateEMA(data, period);
      const ema1Data = ema1.map((val, i) => ({ close: val }));
      const ema2 = calculateEMA(ema1Data, period);
      
      return ema1.map((val1, i) => 2 * val1 - ema2[i]);
    };

    const rsi = calculateRSI(priceData);
    const stochastic = calculateStochastic(priceData);
    const bollinger = calculateBollingerBands(priceData);
    const dema50 = calculateDEMA(priceData, 50);

    return {
      rsi,
      macd: { line: macdLine, signal: signalLine, histogram },
      stochastic,
      bollinger,
      dema50
    };
  };
  
  const generateMockStockData = async (symbol, days = 365) => {
    const data = [];
    let price = Math.random() * 2000 + 500;
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (days - i));
      
      const volatility = 0.025;
      const randomMove = (Math.random() - 0.5) * volatility;
      const trend = Math.sin(i / 30) * 0.002;
      
      const open = price;
      const change = price * (trend + randomMove);
      const close = price + change;
      const high = Math.max(open, close) + Math.random() * price * 0.015;
      const low = Math.min(open, close) - Math.random() * price * 0.015;
      const volume = Math.floor(Math.random() * 5000000 + 1000000);
      
      price = close;
      
      data.push({
        date: date.toISOString().split('T')[0],
        open: Math.round(open * 100) / 100,
        high: Math.round(high * 100) / 100,
        low: Math.round(low * 100) / 100,
        close: Math.round(close * 100) / 100,
        volume: volume
      });
    }
    
    return data;
  };

  const fetchStockNews = async (symbol) => {
    try {
      const newsPrompt = `Get the latest 5 news articles about ${symbol} stock/company. Include title, brief description, sentiment (positive/negative/neutral), and approximate time. Format as structured data.`;
      
      const newsResponse = await InvokeLLM({
        prompt: newsPrompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            news: {
              type: "array",
              items: {
                type: "object", 
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  sentiment: { type: "string" },
                  time: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      return newsResponse.news || [];
    } catch (error) {
      console.error('Error fetching news:', error);
      return [];
    }
  };

  const fetchFundamentals = async (symbol) => {
    try {
      const fundamentalsPrompt = `Get fundamental analysis data for ${symbol} stock: P/E ratio, P/B ratio, market cap, 52-week high/low, EPS, dividend yield, sector, and book value. Provide current accurate data.`;
      
      const fundamentalsResponse = await InvokeLLM({
        prompt: fundamentalsPrompt,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            peRatio: { type: "number" },
            pbRatio: { type: "number" },
            marketCapCrores: { type: "number" },
            week52High: { type: "number" },
            week52Low: { type: "number" },
            eps: { type: "number" },
            dividendYield: { type: "number" },
            sector: { type: "string" },
            bookValue: { type: "number" },
            marketCapCategory: { type: "string" }
          }
        }
      });
      
      return fundamentalsResponse;
    } catch (error) {
      console.error('Error fetching fundamentals:', error);
      return null;
    }
  };

  const analyzeStock = async () => {
    if (!stockSymbol.trim()) {
      setError('Please enter a stock symbol');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const symbol = stockSymbol.toUpperCase();
      
      const fullDataset = await generateMockStockData(symbol, 2000);
      const indicators = calculateTechnicalIndicators(fullDataset);
      
      const enhancedData = fullDataset.map((item, index) => ({
        ...item,
        rsi: indicators.rsi[index],
        macd: indicators.macd.line[index],
        macdSignal: indicators.macd.signal[index],
        macdHistogram: indicators.macd.histogram[index],
        stochK: indicators.stochastic.k[index],
        stochD: indicators.stochastic.d[index],
        bbUpper: indicators.bollinger.upper[index],
        bbMiddle: indicators.bollinger.middle[index], 
        bbLower: indicators.bollinger.lower[index],
        dema50: indicators.dema50[index]
      }));
      
      const [newsData, fundamentalsData] = await Promise.all([
        fetchStockNews(symbol),
        fetchFundamentals(symbol)
      ]);
      
      setStockData(enhancedData);
      setNews(newsData);
      setFundamentals(fundamentalsData);
      
      const detectedSignals = detectCrossoverSignals(enhancedData);
      setSignals(detectedSignals);
      
      await Stock.create({
        symbol,
        last_updated: new Date().toISOString()
      });
      
    } catch (err) {
      setError('Failed to analyze stock. Please try again.');
      console.error('Analysis error:', err);
    } finally {
      setLoading(false);
    }
  };

  const detectCrossoverSignals = (data) => {
    const signals = [];
    const recent = data.slice(-50);
    
    for (let i = 1; i < recent.length; i++) {
      const curr = recent[i];
      const prev = recent[i - 1];
      
      if (prev.macd < prev.macdSignal && curr.macd > curr.macdSignal) {
        signals.push({
          type: 'MACD Bullish Crossover',
          date: curr.date,
          description: 'MACD line crossed above Signal line',
          signal: 'BUY',
          strength: 'Strong'
        });
      }
      
      if (prev.close < prev.dema50 && curr.close > curr.dema50) {
        signals.push({
          type: 'Price Above DEMA50',
          date: curr.date,
          description: 'Price crossed above 50-period DEMA',
          signal: 'BUY',
          strength: 'Medium'
        });
      }
      
      if (prev.stochK < prev.stochD && curr.stochK > curr.stochD && curr.stochK < 80) {
        signals.push({
          type: 'Stochastic Bullish',
          date: curr.date,
          description: '%K crossed above %D below overbought zone',
          signal: 'BUY',
          strength: 'Medium'
        });
      }
    }
    
    return signals.slice(-10);
  };

  const getCurrentSignals = () => {
    if (!stockData || stockData.length === 0) return [];
    
    const latest = stockData[stockData.length - 1];
    const signals = [];
    
    if (latest.rsi < 30) {
      signals.push({ 
        type: 'RSI Oversold', 
        signal: 'BUY', 
        color: 'text-green-600',
        value: latest.rsi.toFixed(1) 
      });
    }
    if (latest.rsi > 70) {
      signals.push({ 
        type: 'RSI Overbought', 
        signal: 'SELL', 
        color: 'text-red-600',
        value: latest.rsi.toFixed(1) 
      });
    }
    if (latest.close > latest.bbUpper) {
      signals.push({ 
        type: 'Above Bollinger Upper', 
        signal: 'CAUTION', 
        color: 'text-yellow-600',
        value: '⚠️' 
      });
    }
    if (latest.close < latest.bbLower) {
      signals.push({ 
        type: 'Below Bollinger Lower', 
        signal: 'BUY', 
        color: 'text-green-600',
        value: '📈' 
      });
    }
    
    return signals;
  };
  
  const handleTimeframeChange = (timeframe) => {
    console.log('Timeframe changed to:', timeframe);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
            🇮🇳 <span>NSE Professional Trading Dashboard</span>
          </h1>
          <p className="text-gray-600 text-lg">Advanced Technical Analysis & Real-time Insights</p>
        </div>

        <Card className="mb-8 shadow-xl">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  value={stockSymbol}
                  onChange={(e) => setStockSymbol(e.target.value.toUpperCase())}
                  placeholder="Enter NSE symbol (e.g., RELIANCE, TCS, INFY)"
                  className="pl-10 h-12 text-lg"
                  onKeyPress={(e) => e.key === 'Enter' && analyzeStock()}
                />
              </div>
              <Button
                onClick={analyzeStock}
                disabled={loading}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 px-8"
              >
                {loading ? (
                  <>
                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Activity className="h-5 w-5 mr-2" />
                    Analyze Stock
                  </>
                )}
              </Button>
            </div>
            
            {error && (
              <Alert variant="destructive" className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {stockData && (
          <>
            <Card className="mb-6 shadow-xl">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-3xl text-blue-600">
                      {stockSymbol}.NS
                    </CardTitle>
                    <p className="text-gray-600 text-lg">
                      {fundamentals?.sector || 'Technology'} | {fundamentals?.marketCapCategory || 'Large Cap'}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-4xl font-bold text-green-600">
                      ₹{stockData[stockData.length - 1].close.toFixed(2)}
                    </div>
                    <p className="text-gray-500">Current Price</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  {getCurrentSignals().map((signal, index) => (
                    <div key={index} className="p-4 rounded-lg border-2 border-gray-200 bg-gray-50">
                      <div className={`font-bold text-lg ${signal.color}`}>
                        {signal.signal}
                      </div>
                      <div className="text-sm text-gray-600">{signal.type}</div>
                      <div className="text-xs text-gray-500">{signal.value}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="charts" className="space-y-6">
              <TabsList className="grid grid-cols-4 lg:grid-cols-4 bg-white shadow-lg">
                <TabsTrigger value="charts" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Charts
                </TabsTrigger>
                <TabsTrigger value="fundamentals" className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Fundamentals
                </TabsTrigger>
                <TabsTrigger value="news" className="flex items-center gap-2">
                  <ExternalLink className="h-4 w-4" />
                  News
                </TabsTrigger>
                <TabsTrigger value="signals" className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Signals
                </TabsTrigger>
              </TabsList>

              <TabsContent value="charts">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <PriceChart 
                    data={stockData} 
                    title="1. Candlestick Chart" 
                    type="candlestick"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <TechnicalIndicators
                    data={stockData}
                    type="rsi"
                    title="2. RSI (14)"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <TechnicalIndicators
                    data={stockData}
                    type="stochastic"
                    title="3. Stochastic Momentum"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <TechnicalIndicators
                    data={stockData}
                    type="macd"
                    title="4. MACD (12, 26, 9)"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <PriceChart
                    data={stockData}
                    title="5. Volume Analysis"
                    type="volume"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <TechnicalIndicators
                    data={stockData}
                    type="bollinger"
                    title="6. Bollinger Bands"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                  <TechnicalIndicators
                    data={stockData}
                    type="dema"
                    title="7. 50 DEMA"
                    timeframe="1mo"
                    onTimeframeChange={handleTimeframeChange}
                  />
                </div>
              </TabsContent>

              <TabsContent value="fundamentals">
                <FundamentalsCard 
                  fundamentals={fundamentals}
                  stockData={stockData}
                  symbol={stockSymbol}
                />
              </TabsContent>

              <TabsContent value="news">
                <NewsSection news={news} symbol={stockSymbol} />
              </TabsContent>

              <TabsContent value="signals">
                <CrossoverSignals signals={signals} />
              </TabsContent>
            </Tabs>
          </>
        )}

        <Card className="mt-8 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-6 w-6 text-yellow-600 mt-1" />
              <div>
                <h3 className="font-semibold text-yellow-800">Real NSE Data Integration</h3>
                <p className="text-yellow-700 mt-1">
                  Currently using simulated data for demonstration. To get real NSE data:
                </p>
                <ul className="list-disc list-inside text-yellow-700 mt-2 space-y-1">
                  <li>Enable backend functions in Dashboard → Settings</li>
                  <li>Upload CSV files with stock data from your trading platform</li>
                  <li>Request NSE API integration via the feedback button</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}