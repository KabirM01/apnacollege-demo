declare module '@/Pages/StockAnalysis' {
  import { ComponentType } from 'react';
  const StockAnalysis: ComponentType<any>;
  export default StockAnalysis;
}

declare module '@/entities/*' {
  const module: any;
  export = module;
}

declare module '@/integrations/*' {
  const module: any;
  export = module;
}

declare module '@/components/ui/*' {
  const module: any;
  export = module;
}